﻿using System;

namespace NetTelegramBotApi.Types
{
    public abstract class ReplyMarkupBase
    {
        // Nothing
    }
}
